#!/bin/bash
# Computer Use Agent Launcher for Linux

APP_DIR="/usr/share/computer-use-agent"
VENV_DIR="$APP_DIR/venv"

# Check if virtual environment exists
if [ ! -d "$VENV_DIR" ]; then
    echo "Error: Computer Use Agent is not properly installed."
    echo "Please reinstall the package."
    exit 1
fi

# Activate virtual environment
source "$VENV_DIR/bin/activate"

# Change to application directory
cd "$APP_DIR"

# Set display for GUI applications
export DISPLAY=${DISPLAY:-:0}

# Start the application
python3 ai_computer_agent_linux.py "$@"
