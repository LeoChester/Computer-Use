#!/bin/bash
set -e

echo "Setting up Computer Use Agent..."

# Create virtual environment
echo "Creating Python virtual environment..."
python3 -m venv /usr/share/computer-use-agent/venv

# Activate virtual environment and install dependencies
echo "Installing Python dependencies..."
source /usr/share/computer-use-agent/venv/bin/activate

# Upgrade pip first
pip install --upgrade pip

# Install dependencies with specific versions for compatibility
echo "Installing PyTorch..."
pip install torch==2.0.1 torchvision==0.15.2 --index-url https://download.pytorch.org/whl/cpu

echo "Installing computer vision dependencies..."
pip install transformers==4.30.2
pip install accelerate==0.20.3
pip install numpy==1.24.3
pip install pillow==10.0.0
pip install opencv-python==4.8.0.74
pip install pyautogui==0.9.54
pip install pynput==1.7.6
pip install screeninfo==0.8.1
pip install psutil==5.9.5
pip install requests==2.31.0

# Download AI models
echo "Downloading AI models (this may take a few minutes)..."
cd /usr/share/computer-use-agent
python3 setup_models_linux.py

# Set permissions
chmod +x /usr/bin/computer-use-agent
chmod +x /usr/share/computer-use-agent/launch.sh

# Update desktop database
if command -v update-desktop-database >/dev/null 2>&1; then
    update-desktop-database /usr/share/applications
fi

echo "Computer Use Agent installation completed successfully!"
echo "You can start it from the applications menu or run 'computer-use-agent' in terminal."

exit 0
