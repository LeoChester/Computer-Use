#!/usr/bin/env python3
# Computer Use Agent - Linux Model Setup
# Downloads and configures AI models for Linux systems.
import os
import sys
import subprocess
from pathlib import Path
import json

def check_python_version():
    # Check if Python version is compatible
    if sys.version_info < (3, 8):
        print("❌ Python 3.8 or higher is required")
        return False
    print(f"✅ Python {sys.version_info.major}.{sys.version_info.minor} detected")
    return True

def download_models():
    # Download and cache vision-language models for computer use
    print("🤖 Preparing computer vision models for GUI control...")
    
    try:
        # Import after installation
        from transformers import BlipProcessor, BlipForConditionalGeneration
        import torch
        from PIL import Image
        import numpy as np
        
        # Check if CUDA is available
        device = "cuda" if torch.cuda.is_available() else "cpu"
        print(f"Using device: {device}")
        
        print("Downloading BLIP-2 model for visual question answering...")
        # BLIP-2 is good for understanding screenshots and answering questions about them
        processor = BlipProcessor.from_pretrained("Salesforce/blip-image-captioning-base")
        model = BlipForConditionalGeneration.from_pretrained("Salesforce/blip-image-captioning-base")
        model.to(device)
        print("✅ BLIP-2 vision model ready")
        
        # Test the models with a dummy image
        print("🧪 Testing vision models...")
        
        # Create a test image (screenshot-like)
        test_image = Image.new('RGB', (800, 600), color='white')
        
        # Test BLIP-2
        inputs = processor(test_image, return_tensors="pt").to(device)
        out = model.generate(**inputs, max_length=50)
        caption = processor.decode(out[0], skip_special_tokens=True)
        print(f"✅ Vision model test passed: {caption}")
        
        return True
        
    except ImportError as e:
        print(f"❌ Missing dependencies: {e}")
        return False
    except Exception as e:
        print(f"❌ Error downloading models: {e}")
        return False

def create_model_config():
    # Create configuration file for vision models
    import torch
    
    config = {
        "models": {
            "vision_language": {
                "name": "Salesforce/blip-image-captioning-base",
                "type": "blip",
                "local_path": "models/vision_language/blip",
                "capabilities": ["image_captioning", "visual_qa", "screen_understanding"]
            }
        },
        "settings": {
            "device": "cuda" if torch.cuda.is_available() else "cpu",
            "max_length": 512,
            "temperature": 0.7,
            "cache_dir": "models/cache",
            "screenshot_interval": 1.0,
            "gui_detection_threshold": 0.7
        },
        "computer_use": {
            "screen_resolution": "auto",
            "mouse_precision": "high",
            "keyboard_delay": 0.1,
            "action_delay": 0.5
        }
    }
    
    with open("model_config.json", "w") as f:
        json.dump(config, f, indent=2)
    
    print("✅ Model configuration saved")

def main():
    # Main setup function
    print("🚀 Computer Use Agent - Linux Model Setup")
    print("==========================================
")
    
    # Check Python version
    if not check_python_version():
        return False
    
    # Create models directory
    models_dir = Path("models")
    models_dir.mkdir(exist_ok=True)
    (models_dir / "vision_language").mkdir(exist_ok=True)
    (models_dir / "cache").mkdir(exist_ok=True)
    
    # Download models
    models_ready = download_models()
    
    if models_ready:
        create_model_config()
        print("
🎉 Linux model setup complete!")
        return True
    else:
        print("
❌ Model setup failed")
        return False

if __name__ == "__main__":
    main()
